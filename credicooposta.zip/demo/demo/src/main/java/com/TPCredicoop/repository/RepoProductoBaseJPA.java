package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Gestor.ProductoBase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="productos_base")
public interface RepoProductoBaseJPA extends JpaRepository<ProductoBase, Long> {
}
