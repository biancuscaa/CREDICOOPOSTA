package com.TPCredicoop.entities.Vendedor;

public enum Estado {
    ACTIVA,
    PAUSADA,
    CANCELADA
}
