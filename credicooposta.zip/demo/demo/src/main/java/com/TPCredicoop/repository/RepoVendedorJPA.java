package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Vendedor.Vendedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="vendedores")
public interface RepoVendedorJPA extends JpaRepository<Vendedor, Long> {
}
