package com.TPCredicoop.entities.Gestor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="tipos_de_personalizacion")
@Getter
@Setter
public class TiposDePersonalizacion extends Persistencia {

    private String nombre;
    private String contenido;
}
