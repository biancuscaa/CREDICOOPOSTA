package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Comprador.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="items")
public interface RepoItemJPA extends JpaRepository<Item, Long> {
}
