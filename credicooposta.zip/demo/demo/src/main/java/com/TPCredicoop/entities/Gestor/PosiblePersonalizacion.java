package com.TPCredicoop.entities.Gestor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name= "posible_personalizacion")
@Getter
@Setter
public class PosiblePersonalizacion extends Persistencia {
    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "areasDePersonalizacion_id")
    private Set<AreasDePersonalizacion> areasDePersonalizacion;
}
