package com.TPCredicoop.entities.Vendedor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="medios_de_pago")
@Getter
@Setter
public class MediosDePago extends Persistencia {
    private String nombre;
    private String contenido; // CVU o informacion para realizar el pago
}
