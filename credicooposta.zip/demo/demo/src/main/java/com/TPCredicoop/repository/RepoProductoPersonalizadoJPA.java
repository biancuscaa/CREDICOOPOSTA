package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Vendedor.ProductoPersonalizado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="productos_personalizados")
public interface RepoProductoPersonalizadoJPA extends JpaRepository<ProductoPersonalizado, Long> {
}
