package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Vendedor.MediosDePago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="medios_de_pago")
public interface RepoMediosDePagoJPA extends JpaRepository<MediosDePago, Long>{
}
