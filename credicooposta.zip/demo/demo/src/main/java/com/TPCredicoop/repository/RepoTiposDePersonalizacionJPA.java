package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Gestor.TiposDePersonalizacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="tipos_de_personalizacion")
public interface RepoTiposDePersonalizacionJPA extends JpaRepository<TiposDePersonalizacion, Long> {
}
