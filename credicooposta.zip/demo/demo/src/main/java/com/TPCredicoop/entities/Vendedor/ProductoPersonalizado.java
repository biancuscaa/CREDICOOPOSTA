package com.TPCredicoop.entities.Vendedor;

import com.TPCredicoop.Persistencia.Persistencia;
import com.TPCredicoop.entities.Gestor.PosiblePersonalizacion;
import com.TPCredicoop.entities.Gestor.ProductoBase;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="producto_personalizado")
@Getter
@Setter
public class ProductoPersonalizado extends Persistencia {
    @OneToOne
    private ProductoBase productoBase;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "personalizacionFinal_id")
    private Set<PosiblePersonalizacion> personalizacionFinal;

    private Integer precioFinal;
    //TODO: funcion que calcule precio final
}
