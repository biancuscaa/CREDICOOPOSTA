package com.TPCredicoop.entities.Gestor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="gestor")
@Getter
@Setter
public class Gestor extends Persistencia {

    @JsonIgnore
    private String contrasenia;
}
