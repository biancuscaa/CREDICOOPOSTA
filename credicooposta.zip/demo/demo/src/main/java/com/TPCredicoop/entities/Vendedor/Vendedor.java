package com.TPCredicoop.entities.Vendedor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;
import net.minidev.json.annotate.JsonIgnore;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="vendedor")
@Getter
@Setter
public class Vendedor extends Persistencia {
    private String nombre;

    @JsonIgnore
    private String contrasenia;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "mediosDePago_id")
    private Set<MediosDePago> mediosDePago;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "productosPersonalizado_id")
    private Set<ProductoPersonalizado> productosPersonalizados;

}
