package com.TPCredicoop.entities.Gestor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="productos")
@Getter
@Setter
public class ProductoBase extends Persistencia {


    private String nombre;
    private String descripcion;
    private String precioBase;

    @Column(name= "tiempoFabricacionEnDias")
    private Integer tiempoFabricacion; //en dias

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "posiblesPersonalizaciones_id")
    private Set<PosiblePersonalizacion> posiblesPersonalizaciones;

}
