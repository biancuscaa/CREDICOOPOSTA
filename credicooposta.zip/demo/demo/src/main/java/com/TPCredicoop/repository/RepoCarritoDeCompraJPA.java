package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Comprador.CarritoDeCompra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="carritos_de_compra")
public interface RepoCarritoDeCompraJPA extends JpaRepository<CarritoDeCompra, Long> {
}
