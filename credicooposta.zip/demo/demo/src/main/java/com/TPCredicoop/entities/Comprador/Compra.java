package com.TPCredicoop.entities.Comprador;

import com.TPCredicoop.Persistencia.Persistencia;
import com.TPCredicoop.entities.Vendedor.Estado;
import com.TPCredicoop.entities.Vendedor.MediosDePago;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="compra")
@Getter
@Setter
public class Compra extends Persistencia {
    @OneToOne
    private CarritoDeCompra carritoDeCompra;

    @Enumerated(EnumType.STRING)
    private Estado estadoCompra;

    @OneToOne
    private MediosDePago medioDePago;

    @Column(name="fecha", columnDefinition = "DATE")
    private LocalDate fechaEmision;
    // factura?

}
