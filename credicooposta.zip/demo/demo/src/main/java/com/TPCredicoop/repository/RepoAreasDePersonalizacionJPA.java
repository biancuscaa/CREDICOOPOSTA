package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Gestor.AreasDePersonalizacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource(path = "areas_de_personalizacion")
public interface RepoAreasDePersonalizacionJPA extends JpaRepository<AreasDePersonalizacion, Long> {
}
