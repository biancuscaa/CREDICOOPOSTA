package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Comprador.Comprador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="compradores")
public interface
RepoCompradorJPA extends JpaRepository<Comprador, Long>{
}
