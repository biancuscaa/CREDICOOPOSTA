package com.TPCredicoop.entities.Comprador;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="comprador")
@Getter
@Setter
public class Comprador extends Persistencia {

    private String nombre;
    //datos de facturacion?

}
