package com.TPCredicoop.entities.Comprador;

import com.TPCredicoop.Persistencia.Persistencia;
import com.TPCredicoop.entities.Vendedor.Estado;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="carrito_de_compra")
@Setter
@Getter
public class CarritoDeCompra extends Persistencia {

    @Enumerated(EnumType.STRING)
    private Estado estadoCarrito;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Item> Items;


    private Integer importe;

    @OneToOne
    private Comprador comprador;

    @Column(name="fecha", columnDefinition = "DATE")
    private LocalDate fecha;
}
