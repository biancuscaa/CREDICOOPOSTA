package com.TPCredicoop.entities.Comprador;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import java.time.LocalDate;
@Entity
@Table(name="factura")
@Getter
@Setter
public class Factura extends Persistencia {
    @OneToOne
    private Compra compra;

}
