package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Gestor.Gestor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="gestores")
public interface RepoGestorJPA extends JpaRepository<Gestor, Long> {
}
