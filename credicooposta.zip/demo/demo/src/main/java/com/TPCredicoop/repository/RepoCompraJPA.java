package com.TPCredicoop.repository;

import com.TPCredicoop.entities.Comprador.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(path="compras")
public interface RepoCompraJPA extends JpaRepository<Compra, Long> {
}
