package com.TPCredicoop.entities.Gestor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="areas_de_personalizacion")
@Getter
@Setter
public class AreasDePersonalizacion extends Persistencia {
    private String nombre;

    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "tiposDePersonalizacion_id")
    private Set<TiposDePersonalizacion> tiposDePersonalizacion;


}
