package com.TPCredicoop.entities.Vendedor;

import com.TPCredicoop.Persistencia.Persistencia;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name="publicacion")
@Getter
@Setter
public class Publicacion extends Persistencia {

    @OneToOne
    private ProductoPersonalizado productoPersonalizado;

    @Column(name="fecha", columnDefinition = "DATE")
    private LocalDate fecha;

    @Enumerated(EnumType.STRING)
    @Column(name="estado_de_publicacion")
    private Estado estadoPublicacion;

    private Integer idVendedor;

}
